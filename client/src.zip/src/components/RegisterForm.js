import React from 'react'

class RegisterForm extends React.Component{
    constructor(props){
        super(props)
        this.state={
            username:'',
            password:'',
            email:''
        }
    }
handleChange=(e)=>{
this.setState({
   [e.target.name]:e.target.value
})
}

handleSubmit=(e)=>{
    e.preventDefault()
    const formData=this.state
    // console.log(formData)
    this.props.handleSubmit(formData)
}
    render(){
        return(
            <div>
                <form onSubmit={this.handleSubmit}>
                    <label>username <input type='text' value={this.state.name} onChange={this.handleChange} name='name'/></label><br/>

                    <label>email <input type='text' value={this.state.email} onChange={this.handleChange} name='email'/></label><br/>

                    <label>password <input type='text' value={this.state.mobile} onChange={this.handleChange} name='mobile'/></label><br/>

                    <input type='submit'/>
                </form>
            </div>
        )
    }
}

export default RegisterForm