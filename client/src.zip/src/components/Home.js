import React from 'react'


export default class Home  extends React.Component{
    render(){
    return(
        <div>
            <h1>welcome to contact</h1>
        </div>
    )
    }
}