import React from 'react';
import {Link,Route,BrowserRouter} from 'react-router-dom'
import Home from './components/Home'
import RegisterForm from './components/RegisterForm'

function App() {
  return (
    <BrowserRouter>
    <div>
<Link to='/'>home</Link> |
<Link to='/users/register'>register</Link> |
<Link to='/users/login'>login</Link>

 <Route path='/' component={Home}/>
 <Route path='/users/register' component={RegisterForm}/>
    </div>
    </BrowserRouter>
   
  )
}

export default App;
